package advisor.util;

public class BackToMenu extends RuntimeException {
    public BackToMenu() { super("Back to main menu"); }
}
