/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package advisor.gui;

import advisor.repo.*;
import advisor.service.*;
import javax.swing.*;

public class GuiMain {
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            try {
                Database.initialize();
                var conn = Database.getConnection();

                CourseRepository courseRepo = new CourseRepository(conn);
                StudentRepository studentRepo = new StudentRepository(conn);
                AdvisorService advisor = new RuleBasedAdvisor(courseRepo);

                AppController controller = new AppController(advisor, courseRepo, studentRepo);
                controller.getFrame().setVisible(true);

            } catch (Exception e) {
                e.printStackTrace();
                JOptionPane.showMessageDialog(null, "Error: " + e.getMessage());
            }
        });
    }
}
