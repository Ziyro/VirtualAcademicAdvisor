/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package advisor.gui;

import javax.swing.*;
import java.awt.*;

public class AdvisorFrame extends JFrame {
    private final AppController controller;
    private final CardLayout layout;
    private final JPanel cards;

    public AdvisorFrame(AppController controller) {
        this.controller = controller;

        setTitle("Virtual Academic Advisor");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(1200, 800);
        setLocationRelativeTo(null);

        layout = new CardLayout();
        cards = new JPanel(layout);
        getContentPane().setLayout(new BorderLayout());

        // main pages
        DashboardPanel dash = new DashboardPanel();
        StudentsPanel students = new StudentsPanel(controller, controller.getStudentRepo());
        CoursesPanel courses = new CoursesPanel(controller.getCourseRepo());
        AdvicePanel advice = new AdvicePanel(controller, controller.getStudentRepo(), controller.getCourseRepo());

        cards.add(dash, "DASH");
        cards.add(students, "STUDENTS");
        cards.add(courses, "COURSES");
        cards.add(advice, "ADVICE");

        add(cards, BorderLayout.CENTER);
        add(new NavPanel(this), BorderLayout.SOUTH);

        layout.show(cards, "DASH");
    }

    // show a page
    public void showCard(String name) {
        layout.show(cards, name);
    }
}
