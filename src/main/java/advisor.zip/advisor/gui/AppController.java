/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package advisor.gui;

import advisor.model.DegreePlan;
import advisor.model.Recommendation;
import advisor.model.Student;
import advisor.repo.CourseRepository;
import advisor.repo.StudentRepository;
import advisor.service.AdvisorService;

import javax.swing.*;
import java.util.List;

public class AppController {
    // connects GUI to services and repos
    private final AdvisorService advisor;
    private final CourseRepository courseRepo;
    private final StudentRepository studentRepo;
    private final AdvisorFrame frame;

    public AppController(AdvisorService advisor, CourseRepository courseRepo, StudentRepository studentRepo) {
        this.advisor = advisor;
        this.courseRepo = courseRepo;
        this.studentRepo = studentRepo;
        this.frame = new AdvisorFrame(this);
    }

    public AdvisorFrame getFrame() { return frame; }
    public AdvisorService getAdvisorService() { return advisor; }
    public CourseRepository getCourseRepo() { return courseRepo; }
    public StudentRepository getStudentRepo() { return studentRepo; }

    // helper: generate + save plan (used by GUI)
    public void generateAndSavePlan(Student s) {
        try {
            List<Recommendation> recs = advisor.recommendNextSemester(s);
            DegreePlan plan = advisor.buildDraftPlan(s, recs);
            studentRepo.savePlan(s.getId(), plan);
            JOptionPane.showMessageDialog(frame, "Plan saved for " + s.getName());
        } catch (Exception e) {
            JOptionPane.showMessageDialog(frame, "Error: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
}
