/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package advisor.gui;

import javax.swing.*;

public final class GuiValidator {
    private GuiValidator() {}

    // check if digits only
    public static boolean isDigits(String s) {
        return s != null && s.matches("\\d+");
    }

    // check if valid name
    public static boolean isPersonName(String s) {
        return s != null && s.trim().replaceAll("\\s+", " ")
                .matches("[A-Za-z][A-Za-z'\\-]*(\\s+[A-Za-z][A-Za-z'\\-]*)+");
    }

    // check if valid GPA
    public static Double parseGpa(String s) {
        try {
            double g = Double.parseDouble(s.trim());
            if (g < 0.0 || g > 9.0) return null;
            return g;
        } catch (Exception e) {
            return null;
        }
    }

    // field helpers
    public static boolean requireDigits(JTextField f, String name) {
        if (!isDigits(f.getText().trim())) {
            JOptionPane.showMessageDialog(null, name + " must be digits only.");
            f.requestFocus();
            return false;
        }
        return true;
    }

    public static boolean requirePersonName(JTextField f, String name) {
        if (!isPersonName(f.getText().trim())) {
            JOptionPane.showMessageDialog(null, "Enter a valid " + name + ".");
            f.requestFocus();
            return false;
        }
        return true;
    }

    public static boolean requireGpaInRange(JTextField f, String name, double min, double max) {
        Double g = parseGpa(f.getText());
        if (g == null) {
            JOptionPane.showMessageDialog(null, name + " must be between " + min + " and " + max + ".");
            f.requestFocus();
            return false;
        }
        return true;
    }
}
