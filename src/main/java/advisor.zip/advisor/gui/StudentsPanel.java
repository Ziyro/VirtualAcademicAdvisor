/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package advisor.gui;

import advisor.model.Student;
import advisor.repo.StudentRepository;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.util.List;

public class StudentsPanel extends JPanel {
    private final StudentRepository repo;
    private final AppController controller;
    private JTable table;
    private DefaultTableModel model;

    public StudentsPanel(AppController controller, StudentRepository repo) {
        this.repo = repo;
        this.controller = controller;

        setLayout(new BorderLayout(10, 10));
        setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));

        JLabel title = new JLabel("Student Records", SwingConstants.CENTER);
        title.setFont(new Font("Segoe UI", Font.BOLD, 24));
        add(title, BorderLayout.NORTH);

        // table setup
        model = new DefaultTableModel(new Object[]{"ID", "Name", "GPA", "Goal"}, 0);
        table = new JTable(model);
        table.setFont(new Font("Segoe UI", Font.PLAIN, 16));
        table.setRowHeight(36);
        table.getTableHeader().setFont(new Font("Segoe UI", Font.BOLD, 18));
        JScrollPane scroll = new JScrollPane(table);
        scroll.setPreferredSize(new Dimension(900, 450));
        add(scroll, BorderLayout.CENTER);

        // buttons
        JPanel bottom = new JPanel(new FlowLayout(FlowLayout.CENTER, 25, 15));
        JButton addBtn = new JButton("Add Student");
        JButton updateBtn = new JButton("Update Courses");
        JButton refreshBtn = new JButton("Refresh");
        for (JButton b : new JButton[]{addBtn, updateBtn, refreshBtn}) {
            b.setFont(new Font("Segoe UI", Font.BOLD, 16));
            b.setPreferredSize(new Dimension(200, 50));
            b.setBackground(new Color(220, 230, 240));
            bottom.add(b);
        }
        add(bottom, BorderLayout.SOUTH);

        addBtn.addActionListener(this::onAdd);
        updateBtn.addActionListener(this::onUpdate);
        refreshBtn.addActionListener(e -> refreshTable());

        refreshTable();
    }

    private void onAdd(ActionEvent e) {
        StudentFormDialog dialog = new StudentFormDialog(controller.getFrame(), repo);
        dialog.setVisible(true);
        refreshTable();
    }

    private void onUpdate(ActionEvent e) {
        int row = table.getSelectedRow();
        if (row < 0) {
            JOptionPane.showMessageDialog(this, "Please select a student first.");
            return;
        }
        String id = (String) model.getValueAt(row, 0);
        try {
            Student s = repo.findById(id).orElseThrow();
            UpdateCompletedDialog dialog = new UpdateCompletedDialog(
                    controller.getFrame(), s, repo, controller.getCourseRepo());
            dialog.setVisible(true);
            refreshTable();
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "Error: " + ex.getMessage());
        }
    }

    private void refreshTable() {
        try {
            List<Student> list = repo.findAll();
            model.setRowCount(0);
            for (Student s : list) {
                model.addRow(new Object[]{s.getId(), s.getName(), s.getGpa(), s.getGoal()});
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Failed to load students: " + e.getMessage());
        }
    }
}
