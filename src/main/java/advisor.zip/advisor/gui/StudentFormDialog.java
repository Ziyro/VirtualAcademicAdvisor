/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package advisor.gui;

import advisor.model.Student;
import advisor.repo.StudentRepository;

import javax.swing.*;
import java.awt.*;

public class StudentFormDialog extends JDialog {
    private final JTextField idField = new JTextField();
    private final JTextField nameField = new JTextField();
    private final JTextField gpaField = new JTextField();
    private final JTextField goalField = new JTextField();
    private final StudentRepository repo;

    public StudentFormDialog(JFrame parent, StudentRepository repo) {
        super(parent, "Add Student", true);
        this.repo = repo;

        setLayout(new GridLayout(5, 2, 10, 10));
        setSize(460, 300);
        setLocationRelativeTo(parent);

        add(new JLabel("Student ID:")); add(idField);
        add(new JLabel("Full Name:")); add(nameField);
        add(new JLabel("GPA (0–9):")); add(gpaField);
        add(new JLabel("Goal:")); add(goalField);

        JButton save = new JButton("Save");
        JButton cancel = new JButton("Cancel");
        add(save); add(cancel);

        save.addActionListener(e -> onSave());
        cancel.addActionListener(e -> dispose());
    }

    private void onSave() {
        if (!GuiValidator.requireDigits(idField, "Student ID")) return;
        if (!GuiValidator.requirePersonName(nameField, "Name")) return;
        if (!GuiValidator.requireGpaInRange(gpaField, "GPA", 0.0, 9.0)) return;

        String id = idField.getText().trim();
        String name = nameField.getText().trim();
        double gpa = Double.parseDouble(gpaField.getText().trim());
        String goal = goalField.getText().trim();

        try {
            Student s = new Student(id, name, gpa, goal);
            repo.upsert(s);
            JOptionPane.showMessageDialog(this, "Student saved!");
            dispose();
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "Error saving student: " + ex.getMessage());
        }
    }
}
