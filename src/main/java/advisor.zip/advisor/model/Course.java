/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package advisor.model;

import java.util.*;

public class Course {
    private String code;
    private String name;
    private int points;
    private List<String> prerequisites;

    public Course(String code, String name, int points, List<String> prerequisites) {
        this.code = code;
        this.name = name;
        this.points = points;
        this.prerequisites = prerequisites != null ? prerequisites : new ArrayList<>();
    }

    public String getCode() { return code; }
    public String getName() { return name; }
    public int getPoints() { return points; }
    public List<String> getPrerequisites() { return prerequisites; }

    @Override
    public String toString() {
        return code + " - " + name + " (" + points + " pts)";
    }
}
