/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package advisor.model;

import java.util.ArrayList;
import java.util.List;

public class DegreePlan {
    private List<String> courses;

    // Empty plan (for new students)
    public DegreePlan(List<String> courses1) {
        this.courses = new ArrayList<>();
    }

    // Add all courses from a list
    public void setCourses(List<String> courses) {
        this.courses = new ArrayList<>(courses);
    }

    // Add a single course
    public void addCourse(String course) {
        courses.add(course);
    }

    // Get list of all courses
    public List<String> getCourses() {
        return courses;
    }

    // Simple text version (for database storage)
    @Override
    public String toString() {
        return String.join(",", courses);
    }

    public void add(String code) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
}
