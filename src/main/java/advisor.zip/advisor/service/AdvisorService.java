/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package advisor.service;

import advisor.model.DegreePlan;
import advisor.model.Recommendation;
import advisor.model.Student;

import java.util.List;

public interface AdvisorService {
    // build recommendations for next semester
    List<Recommendation> recommendNextSemester(Student s) throws Exception;

    // turn recommendations into a simple plan
    DegreePlan buildDraftPlan(Student s, List<Recommendation> recs);
}
