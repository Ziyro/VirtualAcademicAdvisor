/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package advisor.service;

import advisor.model.*;
import advisor.repo.CourseRepository;
import java.sql.SQLException;
import java.util.*;

public class RuleBasedAdvisor implements AdvisorService {

    private final CourseRepository courseRepo;

    public RuleBasedAdvisor(CourseRepository courseRepo) {
        this.courseRepo = courseRepo;
    }

    @Override
    public List<Recommendation> recommendNextSemester(Student s) throws SQLException {
        List<Recommendation> recs = new ArrayList<>();
        List<Course> allCourses = courseRepo.findAll();
        List<String> done = s.getCompleted();

        for (Course c : allCourses) {
            // Skip already completed courses
            if (done.contains(c.getCode())) continue;

            boolean allMet = true;
            for (String pre : c.getPrerequisites()) {
                if (!done.contains(pre.trim())) {
                    allMet = false;
                    break;
                }
            }

            // If all prerequisites are met, recommend it
            if (allMet) {
                recs.add(new Recommendation(c.getCode(),
                        "You can take " + c.getName() + " next semester."));
            }
        }
        return recs;
    }

    @Override
    public DegreePlan buildDraftPlan(Student s, List<Recommendation> recs) {
        List<String> plannedCourses = new ArrayList<>();
        for (Recommendation r : recs) {
            plannedCourses.add(r.getCourseCode());  
        }
        return new DegreePlan(plannedCourses);
    }
}
